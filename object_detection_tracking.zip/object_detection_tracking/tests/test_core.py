"""
tests/test_core.py — Unit tests for detector, tracker, and visualizer.

Run with:
    pytest tests/ -v
"""

from __future__ import annotations
import sys
from pathlib import Path

import numpy as np
import pytest

# Make root importable
sys.path.insert(0, str(Path(__file__).parent.parent))


# ─── Detection dataclass ──────────────────────────────────────────────────────

class TestDetection:
    def _make(self, x1=10, y1=20, x2=110, y2=120):
        from src.detector import Detection
        return Detection(bbox=(x1, y1, x2, y2), confidence=0.85, class_id=0, class_name="person")

    def test_xyxy(self):
        d = self._make()
        assert d.xyxy == (10, 20, 110, 120)

    def test_tlwh(self):
        d = self._make()
        assert d.tlwh == (10, 20, 100, 100)

    def test_center(self):
        d = self._make()
        assert d.center == (60, 70)

    def test_area(self):
        d = self._make()
        assert d.area == 10000

    def test_zero_area(self):
        from src.detector import Detection
        d = Detection(bbox=(5, 5, 5, 5), confidence=0.5, class_id=1, class_name="car")
        assert d.area == 0


# ─── IoU helper ──────────────────────────────────────────────────────────────

class TestIoU:
    def test_perfect_overlap(self):
        from src.tracker import _iou_batch
        a = np.array([[0, 0, 10, 10]])
        iou = _iou_batch(a, a)
        assert abs(iou[0, 0] - 1.0) < 1e-5

    def test_no_overlap(self):
        from src.tracker import _iou_batch
        a = np.array([[0, 0, 10, 10]])
        b = np.array([[20, 20, 30, 30]])
        iou = _iou_batch(a, b)
        assert iou[0, 0] < 1e-5

    def test_partial_overlap(self):
        from src.tracker import _iou_batch
        a = np.array([[0, 0, 10, 10]])
        b = np.array([[5, 0, 15, 10]])  # 50 % overlap
        iou = _iou_batch(a, b)
        assert abs(iou[0, 0] - (50 / 150)) < 0.01


# ─── SORT Tracker ─────────────────────────────────────────────────────────────

class TestSORTTracker:
    @pytest.fixture
    def tracker(self):
        pytest.importorskip("filterpy")
        from src.tracker import SORTTracker, KalmanBoxTracker
        KalmanBoxTracker.count = 0
        return SORTTracker(max_age=5, min_hits=1, iou_threshold=0.30)

    def _det(self, x1, y1, x2, y2, cls=0, name="person"):
        from src.detector import Detection
        return Detection(bbox=(x1, y1, x2, y2), confidence=0.9, class_id=cls, class_name=name)

    def test_first_frame_returns_tracks(self, tracker):
        dets = [self._det(10, 10, 100, 100)]
        tracks = tracker.update(dets)
        assert len(tracks) == 1

    def test_track_id_persists(self, tracker):
        det = self._det(10, 10, 100, 100)
        t1 = tracker.update([det])
        # Slightly move the box
        det2 = self._det(12, 12, 102, 102)
        t2 = tracker.update([det2])
        assert t1[0].track_id == t2[0].track_id

    def test_disappearing_track_removed(self, tracker):
        det = self._det(10, 10, 100, 100)
        tracker.update([det])
        for _ in range(10):   # > max_age
            tracker.update([])
        assert tracker.trackers == []

    def test_class_preserved(self, tracker):
        det = self._det(0, 0, 50, 50, cls=2, name="car")
        tracks = tracker.update([det])
        assert tracks[0].class_name == "car"
        assert tracks[0].class_id   == 2

    def test_multiple_objects(self, tracker):
        dets = [
            self._det(0,   0,  50,  50, name="person"),
            self._det(200, 200, 300, 300, name="car"),
        ]
        tracks = tracker.update(dets)
        assert len(tracks) == 2
        ids = {t.track_id for t in tracks}
        assert len(ids) == 2


# ─── Visualizer (smoke tests — no display needed) ────────────────────────────

class TestVisualizer:
    def test_draw_returns_frame(self):
        from src.visualizer import draw_tracked_objects
        from src.tracker import TrackedObject
        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        tracks = [
            TrackedObject(track_id=1, bbox=(50, 50, 200, 200),
                          confidence=0.9, class_id=0, class_name="person")
        ]
        result = draw_tracked_objects(frame, tracks)
        assert result.shape == frame.shape

    def test_hud_overlay(self):
        from src.visualizer import draw_hud
        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        result = draw_hud(frame, fps=30.0, frame_count=100,
                          active_tracks=3, detector_name="YOLOv8",
                          tracker_name="SORT")
        assert result.shape == frame.shape


# ─── Analytics ────────────────────────────────────────────────────────────────

class TestAnalytics:
    def _track(self, tid, cx, cy):
        from src.tracker import TrackedObject
        r = 20
        return TrackedObject(
            track_id=tid,
            bbox=(cx - r, cy - r, cx + r, cy + r),
            confidence=0.9, class_id=0, class_name="person",
        )

    def test_zone_counter_inside(self):
        from utils.analytics import ZoneCounter
        z = ZoneCounter([(0, 0), (200, 0), (200, 200), (0, 200)], "Test")
        tracks = [self._track(1, 100, 100)]
        info = z.update(tracks)
        assert info["inside_count"] == 1
        assert 1 in info["entered"]

    def test_zone_counter_outside(self):
        from utils.analytics import ZoneCounter
        z = ZoneCounter([(0, 0), (100, 0), (100, 100), (0, 100)], "Test")
        tracks = [self._track(1, 300, 300)]
        info = z.update(tracks)
        assert info["inside_count"] == 0

    def test_line_crossing(self):
        from utils.analytics import LineCrossingCounter
        lc = LineCrossingCounter((0, 100), (200, 100), "Hline")
        # Move from above (y=50) to below (y=150)
        lc.update([self._track(1, 100, 50)])
        lc.update([self._track(1, 100, 150)])
        assert lc.count_a_to_b == 1

    def test_track_statistics(self):
        from utils.analytics import TrackStatistics
        s = TrackStatistics()
        t = self._track(1, 0, 0)
        t.hits = 5
        s.update([t])
        info = s.summary()
        assert info["total_unique_objects"] == 1
        assert "person" in info["by_class"]


# ─── Config loading ───────────────────────────────────────────────────────────

class TestConfig:
    def test_load_yaml(self, tmp_path):
        import yaml
        cfg_path = tmp_path / "test.yaml"
        cfg_path.write_text("source: 0\ndetector:\n  type: yolo\n")
        with open(cfg_path) as f:
            cfg = yaml.safe_load(f)
        assert cfg["source"] == 0
        assert cfg["detector"]["type"] == "yolo"

    def test_build_yolo_detector_missing_ultralytics(self, monkeypatch):
        """build_detector should raise ImportError if ultralytics is absent."""
        import builtins
        real_import = builtins.__import__
        def mock_import(name, *args, **kwargs):
            if name == "ultralytics":
                raise ImportError("mocked")
            return real_import(name, *args, **kwargs)
        monkeypatch.setattr(builtins, "__import__", mock_import)
        from src.detector import build_detector
        with pytest.raises(ImportError):
            build_detector({"type": "yolo"})
