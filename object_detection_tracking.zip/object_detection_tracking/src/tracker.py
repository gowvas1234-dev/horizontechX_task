"""
tracker.py — SORT and DeepSORT object tracking implementations.

SORT  : Simple Online and Realtime Tracking (Bewley et al., 2016)
        Pure-Python implementation; no extra C extensions required.
DeepSORT : Deep SORT with appearance embedding re-id
           Requires `deep-sort-realtime` package.
"""

from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.optimize import linear_sum_assignment

from .detector import Detection


# ─── Tracked object dataclass ─────────────────────────────────────────────────

@dataclass
class TrackedObject:
    """A detected object enriched with a persistent track ID."""
    track_id: int
    bbox: Tuple[int, int, int, int]   # (x1, y1, x2, y2)
    confidence: float
    class_id: int
    class_name: str
    age: int = 1                       # frames since first seen
    hits: int = 1                      # frames confirmed
    time_since_update: int = 0

    @property
    def center(self) -> Tuple[int, int]:
        x1, y1, x2, y2 = self.bbox
        return ((x1 + x2) // 2, (y1 + y2) // 2)

    @property
    def tlwh(self) -> Tuple[int, int, int, int]:
        x1, y1, x2, y2 = self.bbox
        return (x1, y1, x2 - x1, y2 - y1)


# ─── Kalman Filter (minimal, for SORT) ────────────────────────────────────────

class KalmanBoxTracker:
    """
    Kalman Filter for a single bounding-box track.
    State vector: [cx, cy, s, r, dcx, dcy, ds]
        cx, cy  — box centre
        s       — scale (area)
        r       — aspect ratio (width/height), constant
        dc*, ds — velocity terms
    """

    count = 0   # class-level id counter

    def __init__(self, bbox: Tuple[int, int, int, int], class_id: int, class_name: str, conf: float):
        from filterpy.kalman import KalmanFilter

        KalmanBoxTracker.count += 1
        self.id = KalmanBoxTracker.count
        self.class_id = class_id
        self.class_name = class_name
        self.conf = conf
        self.time_since_update = 0
        self.history: List[np.ndarray] = []
        self.hits = 1
        self.hit_streak = 1
        self.age = 1

        self.kf = KalmanFilter(dim_x=7, dim_z=4)
        self.kf.F = np.array([
            [1, 0, 0, 0, 1, 0, 0],
            [0, 1, 0, 0, 0, 1, 0],
            [0, 0, 1, 0, 0, 0, 1],
            [0, 0, 0, 1, 0, 0, 0],
            [0, 0, 0, 0, 1, 0, 0],
            [0, 0, 0, 0, 0, 1, 0],
            [0, 0, 0, 0, 0, 0, 1],
        ], dtype=float)
        self.kf.H = np.array([
            [1, 0, 0, 0, 0, 0, 0],
            [0, 1, 0, 0, 0, 0, 0],
            [0, 0, 1, 0, 0, 0, 0],
            [0, 0, 0, 1, 0, 0, 0],
        ], dtype=float)
        self.kf.R[2:, 2:] *= 10.0
        self.kf.P[4:, 4:] *= 1000.0
        self.kf.P *= 10.0
        self.kf.Q[-1, -1] *= 0.01
        self.kf.Q[4:, 4:] *= 0.01
        self.kf.x[:4] = self._xyxy_to_z(bbox)

    # ------------------------------------------------------------------
    @staticmethod
    def _xyxy_to_z(bbox: Tuple[int, int, int, int]) -> np.ndarray:
        x1, y1, x2, y2 = bbox
        cx = (x1 + x2) / 2.0
        cy = (y1 + y2) / 2.0
        s  = float((x2 - x1) * (y2 - y1))
        r  = float((x2 - x1)) / float(y2 - y1 + 1e-6)
        return np.array([[cx], [cy], [s], [r]], dtype=float)

    @staticmethod
    def _z_to_xyxy(state: np.ndarray) -> Tuple[int, int, int, int]:
        cx, cy, s, r = float(state[0]), float(state[1]), float(state[2]), float(state[3])
        w = np.sqrt(abs(s * r))
        h = abs(s) / (w + 1e-6)
        x1 = int(cx - w / 2)
        y1 = int(cy - h / 2)
        x2 = int(cx + w / 2)
        y2 = int(cy + h / 2)
        return (x1, y1, x2, y2)

    def predict(self) -> Tuple[int, int, int, int]:
        if (self.kf.x[6] + self.kf.x[2]) <= 0:
            self.kf.x[6] *= 0.0
        self.kf.predict()
        self.age += 1
        if self.time_since_update > 0:
            self.hit_streak = 0
        self.time_since_update += 1
        bbox = self._z_to_xyxy(self.kf.x[:4])
        self.history.append(bbox)
        return bbox

    def update(self, bbox: Tuple[int, int, int, int], conf: float):
        self.time_since_update = 0
        self.history = []
        self.hits += 1
        self.hit_streak += 1
        self.conf = conf
        self.kf.update(self._xyxy_to_z(bbox))

    def get_state(self) -> Tuple[int, int, int, int]:
        return self._z_to_xyxy(self.kf.x[:4])


# ─── IoU helper ───────────────────────────────────────────────────────────────

def _iou_batch(bb_test: np.ndarray, bb_gt: np.ndarray) -> np.ndarray:
    """Compute pairwise IoU between two sets of boxes (N×4, M×4)."""
    bb_gt = np.expand_dims(bb_gt, 0)
    bb_test = np.expand_dims(bb_test, 1)
    xx1 = np.maximum(bb_test[..., 0], bb_gt[..., 0])
    yy1 = np.maximum(bb_test[..., 1], bb_gt[..., 1])
    xx2 = np.minimum(bb_test[..., 2], bb_gt[..., 2])
    yy2 = np.minimum(bb_test[..., 3], bb_gt[..., 3])
    w = np.maximum(0.0, xx2 - xx1)
    h = np.maximum(0.0, yy2 - yy1)
    inter = w * h
    area_test = (bb_test[..., 2] - bb_test[..., 0]) * (bb_test[..., 3] - bb_test[..., 1])
    area_gt   = (bb_gt[..., 2]  - bb_gt[..., 0])  * (bb_gt[..., 3]  - bb_gt[..., 1])
    return inter / (area_test + area_gt - inter + 1e-6)


def _associate_detections(
    detections: List[Detection],
    trackers: List[KalmanBoxTracker],
    iou_threshold: float = 0.30,
) -> Tuple[List[Tuple[int, int]], List[int], List[int]]:
    """Hungarian matching between detections and existing Kalman tracks."""
    if not trackers:
        return [], list(range(len(detections))), []

    iou_mat = _iou_batch(
        np.array([d.xyxy for d in detections], dtype=float),
        np.array([t.get_state() for t in trackers], dtype=float),
    )
    row_ind, col_ind = linear_sum_assignment(-iou_mat)
    matched, unmatched_dets, unmatched_trks = [], [], []

    unmatched_dets = [d for d in range(len(detections)) if d not in row_ind]
    unmatched_trks = [t for t in range(len(trackers)) if t not in col_ind]

    for r, c in zip(row_ind, col_ind):
        if iou_mat[r, c] < iou_threshold:
            unmatched_dets.append(r)
            unmatched_trks.append(c)
        else:
            matched.append((r, c))

    return matched, unmatched_dets, unmatched_trks


# ─── SORT Tracker ─────────────────────────────────────────────────────────────

class SORTTracker:
    """
    Simple Online and Realtime Tracking (SORT).

    Parameters
    ----------
    max_age      : frames a track can go unmatched before deletion.
    min_hits     : frames a track must be hit before it's confirmed.
    iou_threshold: IoU required to associate a detection to a track.
    """

    def __init__(
        self,
        max_age: int = 30,
        min_hits: int = 3,
        iou_threshold: float = 0.30,
    ):
        try:
            from filterpy.kalman import KalmanFilter  # noqa: F401
        except ImportError as exc:
            raise ImportError("filterpy is required for SORT. Run: pip install filterpy") from exc

        self.max_age = max_age
        self.min_hits = min_hits
        self.iou_threshold = iou_threshold
        self.trackers: List[KalmanBoxTracker] = []
        self.frame_count = 0
        KalmanBoxTracker.count = 0   # reset global counter

    def update(self, detections: List[Detection]) -> List[TrackedObject]:
        self.frame_count += 1

        # Predict existing tracks
        for trk in self.trackers:
            trk.predict()

        matched, unmatched_dets, unmatched_trks = _associate_detections(
            detections, self.trackers, self.iou_threshold
        )

        # Update matched tracks
        for det_idx, trk_idx in matched:
            self.trackers[trk_idx].update(
                detections[det_idx].xyxy, detections[det_idx].confidence
            )

        # Create new tracks for unmatched detections
        for det_idx in unmatched_dets:
            det = detections[det_idx]
            self.trackers.append(
                KalmanBoxTracker(det.xyxy, det.class_id, det.class_name, det.confidence)
            )

        # Collect results and prune dead tracks
        results: List[TrackedObject] = []
        alive: List[KalmanBoxTracker] = []
        for trk in self.trackers:
            if trk.time_since_update <= self.max_age:
                alive.append(trk)
                if trk.hit_streak >= self.min_hits or self.frame_count <= self.min_hits:
                    results.append(
                        TrackedObject(
                            track_id=trk.id,
                            bbox=trk.get_state(),
                            confidence=trk.conf,
                            class_id=trk.class_id,
                            class_name=trk.class_name,
                            age=trk.age,
                            hits=trk.hits,
                            time_since_update=trk.time_since_update,
                        )
                    )
        self.trackers = alive
        return results


# ─── DeepSORT Tracker ─────────────────────────────────────────────────────────

class DeepSORTTracker:
    """
    DeepSORT tracker backed by deep-sort-realtime.

    Parameters
    ----------
    max_age        : frames before a track is deleted.
    n_init         : frames before a track is confirmed.
    embedder       : feature extractor model name passed to deep-sort-realtime.
                     Options: 'mobilenet', 'torchreid', 'clip_ViT-B/16', …
    max_cosine_dist: cosine distance threshold for re-id matching.
    nn_budget      : max size of appearance descriptor gallery per track.
    """

    def __init__(
        self,
        max_age: int = 30,
        n_init: int = 3,
        embedder: str = "mobilenet",
        max_cosine_dist: float = 0.4,
        nn_budget: Optional[int] = 100,
    ):
        try:
            from deep_sort_realtime.deepsort_tracker import DeepSort
        except ImportError as exc:
            raise ImportError(
                "deep-sort-realtime is required. Run: pip install deep-sort-realtime"
            ) from exc

        from deep_sort_realtime.deepsort_tracker import DeepSort
        self._ds = DeepSort(
            max_age=max_age,
            n_init=n_init,
            embedder=embedder,
            max_cosine_distance=max_cosine_dist,
            nn_budget=nn_budget,
        )

    def update(self, detections: List[Detection], frame: np.ndarray) -> List[TrackedObject]:
        """
        Parameters
        ----------
        detections : list of Detection objects
        frame      : current BGR frame (for appearance embedding)

        Returns
        -------
        list of TrackedObject
        """
        # deep-sort-realtime expects: list of ([x1,y1,w,h], conf, class_id)
        ds_input = [
            (list(det.tlwh), det.confidence, det.class_id)
            for det in detections
        ]
        tracks = self._ds.update_tracks(ds_input, frame=frame)

        results: List[TrackedObject] = []
        for track in tracks:
            if not track.is_confirmed():
                continue
            ltrb = track.to_ltrb()
            x1, y1, x2, y2 = map(int, ltrb)
            cls = track.det_class if hasattr(track, "det_class") else 0
            # Try to get class name from the original detections by matching bbox
            class_name = str(cls)
            for det in detections:
                if abs(det.class_id - cls) < 0.5:
                    class_name = det.class_name
                    break
            results.append(
                TrackedObject(
                    track_id=track.track_id,
                    bbox=(x1, y1, x2, y2),
                    confidence=track.det_conf if track.det_conf else 0.0,
                    class_id=int(cls),
                    class_name=class_name,
                )
            )
        return results


# ─── Factory ──────────────────────────────────────────────────────────────────

def build_tracker(cfg: dict):
    """
    Build a tracker from a config dict.

    Keys:
        type            : "sort" | "deepsort"
        max_age         : int
        min_hits / n_init: int
        iou_threshold   : float  (SORT)
        embedder        : str    (DeepSORT)
        max_cosine_dist : float  (DeepSORT)
    """
    ttype = cfg.get("type", "sort").lower()
    if ttype == "sort":
        return SORTTracker(
            max_age=cfg.get("max_age", 30),
            min_hits=cfg.get("min_hits", 3),
            iou_threshold=cfg.get("iou_threshold", 0.30),
        )
    elif ttype == "deepsort":
        return DeepSORTTracker(
            max_age=cfg.get("max_age", 30),
            n_init=cfg.get("n_init", 3),
            embedder=cfg.get("embedder", "mobilenet"),
            max_cosine_dist=cfg.get("max_cosine_dist", 0.4),
            nn_budget=cfg.get("nn_budget", 100),
        )
    else:
        raise ValueError(f"Unknown tracker type '{ttype}'. Use 'sort' or 'deepsort'.")
