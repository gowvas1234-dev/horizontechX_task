"""
visualizer.py — Bounding-box drawing, overlays, and HUD rendering.
"""

from __future__ import annotations
import colorsys
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

from .tracker import TrackedObject


# ─── Colour palette ───────────────────────────────────────────────────────────

def _id_to_color(track_id: int, saturation: float = 0.85, value: float = 0.95) -> Tuple[int, int, int]:
    """Generate a visually distinct BGR colour from a track ID."""
    hue = (track_id * 0.618033988749895) % 1.0          # golden-ratio spread
    r, g, b = colorsys.hsv_to_rgb(hue, saturation, value)
    return (int(b * 255), int(g * 255), int(r * 255))   # BGR


# ─── Core draw functions ──────────────────────────────────────────────────────

def draw_tracked_objects(
    frame: np.ndarray,
    tracks: List[TrackedObject],
    *,
    line_thickness: int = 2,
    font_scale: float = 0.55,
    font_thickness: int = 1,
    show_confidence: bool = True,
    show_track_id: bool = True,
    show_class: bool = True,
    show_trail: bool = False,
    trail_history: Optional[Dict[int, List[Tuple[int, int]]]] = None,
    trail_length: int = 30,
    alpha_fill: float = 0.12,
) -> np.ndarray:
    """
    Draw bounding boxes and labels for a list of tracked objects.

    Parameters
    ----------
    frame            : BGR frame to draw on (modified in-place).
    tracks           : list of TrackedObject from the tracker.
    line_thickness   : box border thickness in pixels.
    font_scale       : label font scale.
    font_thickness   : label font stroke thickness.
    show_confidence  : include detection confidence in the label.
    show_track_id    : include track ID in the label.
    show_class       : include class name in the label.
    show_trail       : draw a centroid trail behind each object.
    trail_history    : dict {track_id: [centroid, …]} maintained by the caller.
    trail_length     : maximum number of trail points kept.
    alpha_fill       : opacity of the semi-transparent box fill (0 = none).

    Returns
    -------
    The annotated frame.
    """
    overlay = frame.copy()

    for obj in tracks:
        color = _id_to_color(obj.track_id)
        x1, y1, x2, y2 = obj.bbox

        # Semi-transparent fill
        if alpha_fill > 0:
            cv2.rectangle(overlay, (x1, y1), (x2, y2), color, -1)
            cv2.addWeighted(overlay, alpha_fill, frame, 1 - alpha_fill, 0, frame)
            overlay = frame.copy()

        # Border
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, line_thickness)

        # Trail
        if show_trail and trail_history is not None:
            cx, cy = obj.center
            trail_history.setdefault(obj.track_id, []).append((cx, cy))
            if len(trail_history[obj.track_id]) > trail_length:
                trail_history[obj.track_id].pop(0)
            pts = trail_history[obj.track_id]
            for i in range(1, len(pts)):
                fade = int(255 * i / len(pts))
                faded = tuple(int(c * fade / 255) for c in color)
                cv2.line(frame, pts[i - 1], pts[i], faded, 1)

        # Label
        parts: List[str] = []
        if show_class:
            parts.append(obj.class_name)
        if show_track_id:
            parts.append(f"#{obj.track_id}")
        if show_confidence:
            parts.append(f"{obj.confidence:.0%}")
        label = "  ".join(parts)

        (tw, th), baseline = cv2.getTextSize(
            label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, font_thickness
        )
        tag_x1 = x1
        tag_y1 = max(y1 - th - baseline - 4, 0)
        tag_x2 = x1 + tw + 8
        tag_y2 = max(y1, th + baseline + 4)

        cv2.rectangle(frame, (tag_x1, tag_y1), (tag_x2, tag_y2), color, -1)
        cv2.putText(
            frame,
            label,
            (tag_x1 + 4, tag_y2 - baseline - 2),
            cv2.FONT_HERSHEY_SIMPLEX,
            font_scale,
            (255, 255, 255),
            font_thickness,
            cv2.LINE_AA,
        )

        # Corner accents (small tick marks)
        _draw_corners(frame, (x1, y1, x2, y2), color, line_thickness + 1)

    return frame


def _draw_corners(
    frame: np.ndarray,
    bbox: Tuple[int, int, int, int],
    color: Tuple[int, int, int],
    thickness: int,
    length: int = 12,
) -> None:
    """Draw corner tick marks for a sharper look."""
    x1, y1, x2, y2 = bbox
    corners = [
        ((x1, y1), (x1 + length, y1), (x1, y1 + length)),
        ((x2, y1), (x2 - length, y1), (x2, y1 + length)),
        ((x1, y2), (x1 + length, y2), (x1, y2 - length)),
        ((x2, y2), (x2 - length, y2), (x2, y2 - length)),
    ]
    for apex, h_end, v_end in corners:
        cv2.line(frame, apex, h_end, color, thickness)
        cv2.line(frame, apex, v_end, color, thickness)


# ─── HUD overlay ──────────────────────────────────────────────────────────────

def draw_hud(
    frame: np.ndarray,
    fps: float,
    frame_count: int,
    active_tracks: int,
    detector_name: str,
    tracker_name: str,
    avg_inference_ms: float = 0.0,
) -> np.ndarray:
    """Draw a semi-transparent HUD in the top-left corner."""
    lines = [
        f"Detector : {detector_name}",
        f"Tracker  : {tracker_name}",
        f"FPS      : {fps:>6.1f}",
        f"Infer ms : {avg_inference_ms:>6.1f}",
        f"Tracks   : {active_tracks:>6d}",
        f"Frame    : {frame_count:>6d}",
    ]
    font      = cv2.FONT_HERSHEY_SIMPLEX
    fscale    = 0.48
    fthick    = 1
    pad       = 8
    line_h    = 18
    panel_h   = pad * 2 + line_h * len(lines)
    panel_w   = 240

    # Dark panel
    overlay = frame.copy()
    cv2.rectangle(overlay, (10, 10), (10 + panel_w, 10 + panel_h), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.55, frame, 0.45, 0, frame)

    # Accent bar
    cv2.rectangle(frame, (10, 10), (14, 10 + panel_h), (0, 200, 255), -1)

    for i, line in enumerate(lines):
        y = 10 + pad + (i + 1) * line_h
        cv2.putText(frame, line, (20, y), font, fscale, (200, 200, 200), fthick, cv2.LINE_AA)

    return frame


def draw_zone(
    frame: np.ndarray,
    polygon: List[Tuple[int, int]],
    color: Tuple[int, int, int] = (0, 255, 255),
    alpha: float = 0.20,
    label: str = "",
) -> np.ndarray:
    """Draw a semi-transparent polygon zone (e.g. ROI or count line)."""
    pts = np.array(polygon, dtype=np.int32)
    overlay = frame.copy()
    cv2.fillPoly(overlay, [pts], color)
    cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0, frame)
    cv2.polylines(frame, [pts], True, color, 2)
    if label:
        cx = int(np.mean([p[0] for p in polygon]))
        cy = int(np.mean([p[1] for p in polygon]))
        cv2.putText(frame, label, (cx - 30, cy), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2, cv2.LINE_AA)
    return frame
