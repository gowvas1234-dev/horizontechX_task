"""
detector.py — YOLOv8 / Faster R-CNN object detection wrapper
Handles model loading, inference, and returning raw detections.
"""

from __future__ import annotations
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import numpy as np

# ─── Detection result dataclass ───────────────────────────────────────────────

@dataclass
class Detection:
    """Single bounding-box detection result."""
    bbox: Tuple[int, int, int, int]   # (x1, y1, x2, y2)
    confidence: float
    class_id: int
    class_name: str

    @property
    def tlwh(self) -> Tuple[int, int, int, int]:
        """Return (top-left-x, top-left-y, width, height) — used by SORT/DeepSORT."""
        x1, y1, x2, y2 = self.bbox
        return (x1, y1, x2 - x1, y2 - y1)

    @property
    def xyxy(self) -> Tuple[int, int, int, int]:
        return self.bbox

    @property
    def center(self) -> Tuple[int, int]:
        x1, y1, x2, y2 = self.bbox
        return ((x1 + x2) // 2, (y1 + y2) // 2)

    @property
    def area(self) -> int:
        x1, y1, x2, y2 = self.bbox
        return (x2 - x1) * (y2 - y1)


# ─── YOLO Detector ────────────────────────────────────────────────────────────

class YOLODetector:
    """
    YOLOv8 real-time object detector via Ultralytics.

    Parameters
    ----------
    model_path : str
        Path to a .pt weights file or one of the shorthand names
        ('yolov8n', 'yolov8s', 'yolov8m', 'yolov8l', 'yolov8x').
    conf_threshold : float
        Minimum confidence to keep a detection.
    iou_threshold : float
        IoU threshold for NMS.
    classes : list[int] | None
        If given, only these COCO class IDs are returned.
    device : str
        'cuda', 'cpu', or '' (auto).
    """

    def __init__(
        self,
        model_path: str = "yolov8n.pt",
        conf_threshold: float = 0.40,
        iou_threshold: float = 0.45,
        classes: Optional[List[int]] = None,
        device: str = "",
    ):
        try:
            from ultralytics import YOLO
        except ImportError as exc:
            raise ImportError(
                "ultralytics is not installed. Run: pip install ultralytics"
            ) from exc

        self.model = YOLO(model_path)
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold
        self.classes = classes
        self.device = device
        self._names: dict = self.model.names          # {id: name}
        self._inference_times: List[float] = []

    # ------------------------------------------------------------------
    def detect(self, frame: np.ndarray) -> List[Detection]:
        """Run inference on a single BGR frame and return detections."""
        t0 = time.perf_counter()

        results = self.model.predict(
            source=frame,
            conf=self.conf_threshold,
            iou=self.iou_threshold,
            classes=self.classes,
            device=self.device,
            verbose=False,
        )

        self._inference_times.append(time.perf_counter() - t0)

        detections: List[Detection] = []
        for r in results:
            boxes = r.boxes
            if boxes is None:
                continue
            for box in boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                conf = float(box.conf[0])
                cls  = int(box.cls[0])
                detections.append(
                    Detection(
                        bbox=(x1, y1, x2, y2),
                        confidence=conf,
                        class_id=cls,
                        class_name=self._names.get(cls, str(cls)),
                    )
                )
        return detections

    @property
    def avg_inference_ms(self) -> float:
        if not self._inference_times:
            return 0.0
        return 1000 * sum(self._inference_times) / len(self._inference_times)


# ─── Faster R-CNN Detector (PyTorch torchvision) ──────────────────────────────

class FasterRCNNDetector:
    """
    Faster R-CNN detector backed by torchvision pre-trained weights.

    Parameters
    ----------
    model_name : str
        'fasterrcnn_resnet50_fpn' | 'fasterrcnn_mobilenet_v3_large_fpn'
    conf_threshold : float
        Score threshold for filtering boxes.
    classes : list[int] | None
        COCO class IDs to keep (1-indexed, as returned by torchvision).
        None = keep all.
    device : str | None
        'cuda' | 'cpu' | None (auto).
    """

    # COCO 1-indexed label map (torchvision uses these IDs)
    COCO_NAMES = {
        1: "person", 2: "bicycle", 3: "car", 4: "motorcycle", 5: "airplane",
        6: "bus", 7: "train", 8: "truck", 9: "boat", 10: "traffic light",
        11: "fire hydrant", 13: "stop sign", 14: "parking meter", 15: "bench",
        16: "bird", 17: "cat", 18: "dog", 19: "horse", 20: "sheep",
        21: "cow", 22: "elephant", 23: "bear", 24: "zebra", 25: "giraffe",
        27: "backpack", 28: "umbrella", 31: "handbag", 32: "tie",
        33: "suitcase", 34: "frisbee", 35: "skis", 36: "snowboard",
        37: "sports ball", 38: "kite", 39: "baseball bat", 40: "baseball glove",
        41: "skateboard", 42: "surfboard", 43: "tennis racket", 44: "bottle",
        46: "wine glass", 47: "cup", 48: "fork", 49: "knife", 50: "spoon",
        51: "bowl", 52: "banana", 53: "apple", 54: "sandwich", 55: "orange",
        56: "broccoli", 57: "carrot", 58: "hot dog", 59: "pizza", 60: "donut",
        61: "cake", 62: "chair", 63: "couch", 64: "potted plant", 65: "bed",
        67: "dining table", 70: "toilet", 72: "tv", 73: "laptop", 74: "mouse",
        75: "remote", 76: "keyboard", 77: "cell phone", 78: "microwave",
        79: "oven", 80: "toaster", 81: "sink", 82: "refrigerator",
        84: "book", 85: "clock", 86: "vase", 87: "scissors",
        88: "teddy bear", 89: "hair drier", 90: "toothbrush",
    }

    def __init__(
        self,
        model_name: str = "fasterrcnn_resnet50_fpn",
        conf_threshold: float = 0.50,
        classes: Optional[List[int]] = None,
        device: Optional[str] = None,
    ):
        try:
            import torch
            import torchvision
        except ImportError as exc:
            raise ImportError(
                "torch and torchvision are required. "
                "Visit https://pytorch.org for install instructions."
            ) from exc

        import torch
        import torchvision
        from torchvision.models.detection import (
            fasterrcnn_resnet50_fpn,
            fasterrcnn_resnet50_fpn_v2,
            fasterrcnn_mobilenet_v3_large_fpn,
            FasterRCNN_ResNet50_FPN_Weights,
            FasterRCNN_ResNet50_FPN_V2_Weights,
            FasterRCNN_MobileNet_V3_Large_FPN_Weights,
        )

        self.device = torch.device(
            device if device else ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self.conf_threshold = conf_threshold
        self.classes = set(classes) if classes else None
        self._inference_times: List[float] = []

        model_map = {
            "fasterrcnn_resnet50_fpn": (
                fasterrcnn_resnet50_fpn,
                FasterRCNN_ResNet50_FPN_Weights.DEFAULT,
            ),
            "fasterrcnn_resnet50_fpn_v2": (
                fasterrcnn_resnet50_fpn_v2,
                FasterRCNN_ResNet50_FPN_V2_Weights.DEFAULT,
            ),
            "fasterrcnn_mobilenet_v3_large_fpn": (
                fasterrcnn_mobilenet_v3_large_fpn,
                FasterRCNN_MobileNet_V3_Large_FPN_Weights.DEFAULT,
            ),
        }
        if model_name not in model_map:
            raise ValueError(f"Unknown model: {model_name}. Choose from {list(model_map)}")

        fn, weights = model_map[model_name]
        self.model = fn(weights=weights)
        self.model.eval()
        self.model.to(self.device)
        self._transforms = weights.transforms()

    def detect(self, frame: np.ndarray) -> List[Detection]:
        import torch
        from PIL import Image

        t0 = time.perf_counter()
        pil_img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        tensor = self._transforms(pil_img).unsqueeze(0).to(self.device)

        with torch.no_grad():
            outputs = self.model(tensor)[0]

        self._inference_times.append(time.perf_counter() - t0)

        detections: List[Detection] = []
        for box, score, label in zip(
            outputs["boxes"].cpu().numpy(),
            outputs["scores"].cpu().numpy(),
            outputs["labels"].cpu().numpy(),
        ):
            if score < self.conf_threshold:
                continue
            if self.classes and label not in self.classes:
                continue
            x1, y1, x2, y2 = map(int, box)
            detections.append(
                Detection(
                    bbox=(x1, y1, x2, y2),
                    confidence=float(score),
                    class_id=int(label),
                    class_name=self.COCO_NAMES.get(int(label), str(label)),
                )
            )
        return detections

    @property
    def avg_inference_ms(self) -> float:
        if not self._inference_times:
            return 0.0
        return 1000 * sum(self._inference_times) / len(self._inference_times)


# ─── Factory ──────────────────────────────────────────────────────────────────

def build_detector(cfg: dict):
    """
    Build a detector from a config dict.

    Expected keys:
        type          : "yolo" | "faster_rcnn"
        model_path    : path / model name
        conf_threshold: float
        iou_threshold : float  (YOLO only)
        classes       : list[int] | null
        device        : str
    """
    dtype = cfg.get("type", "yolo").lower()
    if dtype == "yolo":
        return YOLODetector(
            model_path=cfg.get("model_path", "yolov8n.pt"),
            conf_threshold=cfg.get("conf_threshold", 0.40),
            iou_threshold=cfg.get("iou_threshold", 0.45),
            classes=cfg.get("classes"),
            device=cfg.get("device", ""),
        )
    elif dtype == "faster_rcnn":
        return FasterRCNNDetector(
            model_name=cfg.get("model_path", "fasterrcnn_resnet50_fpn"),
            conf_threshold=cfg.get("conf_threshold", 0.50),
            classes=cfg.get("classes"),
            device=cfg.get("device"),
        )
    else:
        raise ValueError(f"Unknown detector type '{dtype}'. Use 'yolo' or 'faster_rcnn'.")
