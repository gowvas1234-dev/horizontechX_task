#!/usr/bin/env python3
"""
run.py — Main entry point for the Object Detection & Tracking pipeline.

Usage
-----
  # Webcam with default config (YOLOv8n + SORT)
  python run.py

  # Custom config file
  python run.py --config configs/yolo_deepsort.yaml

  # Override source and model on the fly
  python run.py --source videos/street.mp4 --model yolov8m.pt

  # Use Faster R-CNN instead
  python run.py --config configs/fasterrcnn_sort.yaml

Keyboard shortcuts (while window is open)
------------------------------------------
  q / Esc  — quit
  s        — screenshot (saved to output/screenshots/)
  p        — pause / resume
  t        — toggle trail display
  h        — toggle HUD
"""

from __future__ import annotations
import argparse
import time
from pathlib import Path
from typing import Dict, List, Optional

import cv2
import yaml

from src.detector import build_detector
from src.tracker import build_tracker, TrackedObject
from src.visualizer import draw_tracked_objects, draw_hud, draw_zone
from utils.video_io import VideoReader, VideoWriter, FPSCounter
from utils.analytics import ZoneCounter, LineCrossingCounter, TrackStatistics


# ─── Config loading ───────────────────────────────────────────────────────────

def load_config(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def merge_cli_overrides(cfg: dict, args: argparse.Namespace) -> dict:
    """Apply CLI overrides on top of the YAML config."""
    if args.source is not None:
        try:
            cfg["source"] = int(args.source)
        except ValueError:
            cfg["source"] = args.source
    if args.model is not None:
        cfg.setdefault("detector", {})["model_path"] = args.model
    if args.conf is not None:
        cfg.setdefault("detector", {})["conf_threshold"] = args.conf
    if args.tracker is not None:
        cfg.setdefault("tracker", {})["type"] = args.tracker
    if args.device is not None:
        cfg.setdefault("detector", {})["device"] = args.device
    if args.no_display:
        cfg.setdefault("display", {})["show_window"] = False
    if args.save_video:
        cfg.setdefault("output", {})["save_video"] = True
    return cfg


# ─── Pipeline ─────────────────────────────────────────────────────────────────

def run(cfg: dict) -> None:
    det_cfg  = cfg.get("detector", {})
    trk_cfg  = cfg.get("tracker",  {})
    disp_cfg = cfg.get("display",  {})
    out_cfg  = cfg.get("output",   {})
    ana_cfg  = cfg.get("analytics",{})

    detector = build_detector(det_cfg)
    tracker  = build_tracker(trk_cfg)

    source        = cfg.get("source", 0)
    resize_w      = cfg.get("resize_width",  0)
    resize_h      = cfg.get("resize_height", 0)

    show_window   = disp_cfg.get("show_window", True)
    win_name      = disp_cfg.get("window_name", "Detection & Tracking")
    show_conf     = disp_cfg.get("show_confidence", True)
    show_id       = disp_cfg.get("show_track_id",   True)
    show_cls      = disp_cfg.get("show_class",       True)
    show_trail    = disp_cfg.get("show_trail",        True)
    trail_length  = disp_cfg.get("trail_length",      40)
    alpha_fill    = disp_cfg.get("alpha_fill",         0.12)
    line_thick    = disp_cfg.get("line_thickness",      2)

    save_video    = out_cfg.get("save_video",  False)
    output_path   = out_cfg.get("output_path", "output/result.mp4")

    # ── Analytics setup ───────────────────────────────────────────
    zones:    List[ZoneCounter]        = []
    crossings: List[LineCrossingCounter] = []
    stats = TrackStatistics()

    if ana_cfg.get("enabled", False):
        for z in ana_cfg.get("zones", []):
            zones.append(ZoneCounter(z["polygon"], z.get("name", "Zone")))
        for lc in ana_cfg.get("line_crossings", []):
            crossings.append(
                LineCrossingCounter(lc["p1"], lc["p2"], lc.get("name", "Line"))
            )

    # ── Open video source ─────────────────────────────────────────
    reader = VideoReader(source, resize_w, resize_h)
    fps_counter = FPSCounter(window=30)
    trail_history: Dict[int, list] = {}
    writer: Optional[VideoWriter] = None
    frame_idx = 0
    paused  = False
    show_hud = True

    det_name = det_cfg.get("type", "yolo").upper()
    if det_cfg.get("type", "yolo").lower() == "yolo":
        model_name = det_cfg.get("model_path", "yolov8n").replace(".pt", "").upper()
        det_name = f"YOLOv8 ({model_name})"
    elif det_cfg.get("type", "").lower() == "faster_rcnn":
        det_name = f"Faster R-CNN ({det_cfg.get('model_path','resnet50')})"

    trk_name = trk_cfg.get("type", "sort").upper()

    print(f"\n{'─'*55}")
    print(f"  Detector : {det_name}")
    print(f"  Tracker  : {trk_name}")
    print(f"  Source   : {source}")
    print(f"{'─'*55}")
    print("  Press  q / Esc  to quit")
    print("  Press  p        to pause/resume")
    print("  Press  s        to screenshot")
    print("  Press  t        to toggle trail")
    print("  Press  h        to toggle HUD")
    print(f"{'─'*55}\n")

    # Output directory
    Path("output/screenshots").mkdir(parents=True, exist_ok=True)

    try:
        for frame in reader:
            if paused:
                cv2.waitKey(30)
                continue

            frame_idx += 1

            # ── Detection ─────────────────────────────────────────
            if trk_cfg.get("type", "sort").lower() == "deepsort":
                detections = detector.detect(frame)
                tracks: List[TrackedObject] = tracker.update(detections, frame)
            else:
                detections = detector.detect(frame)
                tracks = tracker.update(detections)

            # ── Analytics update ──────────────────────────────────
            stats.update(tracks)
            for z in zones:
                z.update(tracks)
            for lc in crossings:
                lc.update(tracks)

            # ── Draw zones ────────────────────────────────────────
            for z in zones:
                draw_zone(frame, z.polygon, label=f"{z.name}: {z.current_count}")
            for lc in crossings:
                import numpy as np
                cv2.line(frame, tuple(map(int, lc.p1)), tuple(map(int, lc.p2)), (0, 255, 0), 2)
                cv2.putText(
                    frame,
                    f"{lc.name} ↑{lc.count_a_to_b} ↓{lc.count_b_to_a}",
                    (int(lc.p1[0]) + 5, int(lc.p1[1]) - 8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 1, cv2.LINE_AA,
                )

            # ── Draw detections & HUD ─────────────────────────────
            draw_tracked_objects(
                frame,
                tracks,
                line_thickness=line_thick,
                show_confidence=show_conf,
                show_track_id=show_id,
                show_class=show_cls,
                show_trail=show_trail,
                trail_history=trail_history,
                trail_length=trail_length,
                alpha_fill=alpha_fill,
            )

            fps = fps_counter.tick()
            if show_hud:
                draw_hud(
                    frame,
                    fps=fps,
                    frame_count=frame_idx,
                    active_tracks=len(tracks),
                    detector_name=det_name,
                    tracker_name=trk_name,
                    avg_inference_ms=detector.avg_inference_ms,
                )

            # ── Save video ────────────────────────────────────────
            if save_video:
                if writer is None:
                    h, w = frame.shape[:2]
                    writer = VideoWriter(output_path, reader.fps or 30.0, (w, h))
                writer.write(frame)

            # ── Display ───────────────────────────────────────────
            if show_window:
                cv2.imshow(win_name, frame)
                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), 27):         # q or Esc
                    break
                elif key == ord("p"):
                    paused = not paused
                elif key == ord("s"):
                    spath = f"output/screenshots/frame_{frame_idx:06d}.jpg"
                    cv2.imwrite(spath, frame)
                    print(f"  Screenshot saved → {spath}")
                elif key == ord("t"):
                    show_trail = not show_trail
                    print(f"  Trail: {'ON' if show_trail else 'OFF'}")
                elif key == ord("h"):
                    show_hud = not show_hud
            else:
                if frame_idx % 100 == 0:
                    print(f"  Frame {frame_idx:6d}  |  FPS {fps:5.1f}  |  Tracks {len(tracks)}")

    finally:
        reader.release()
        if writer:
            writer.release()
        cv2.destroyAllWindows()
        summary = stats.summary()
        print(f"\n{'─'*55}")
        print("  Session summary")
        print(f"  Frames processed : {frame_idx}")
        print(f"  Unique objects   : {summary['total_unique_objects']}")
        print(f"  By class         : {summary['by_class']}")
        print(f"  Avg track life   : {summary['avg_track_lifetime']:.1f} frames")
        if save_video:
            print(f"  Video saved to   : {output_path}")
        print(f"{'─'*55}\n")


# ─── CLI ──────────────────────────────────────────────────────────────────────

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Real-Time Object Detection & Tracking — YOLOv8/Faster R-CNN + SORT/DeepSORT",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument(
        "--config", "-c",
        default="configs/yolo_sort.yaml",
        help="Path to YAML config file (default: configs/yolo_sort.yaml)",
    )
    p.add_argument("--source",   "-s", default=None, help="Video source (0=webcam, or path/URL)")
    p.add_argument("--model",    "-m", default=None, help="Model path override (e.g. yolov8m.pt)")
    p.add_argument("--conf",           default=None, type=float, help="Confidence threshold override")
    p.add_argument("--tracker",        default=None, choices=["sort","deepsort"], help="Tracker override")
    p.add_argument("--device",         default=None, help="Device override: cuda | cpu")
    p.add_argument("--no-display",     action="store_true", help="Suppress OpenCV window (headless)")
    p.add_argument("--save-video",     action="store_true", help="Save annotated output video")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg  = load_config(args.config)
    cfg  = merge_cli_overrides(cfg, args)
    run(cfg)
