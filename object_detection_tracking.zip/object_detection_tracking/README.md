# 🎯 Object Detection & Tracking — Real-Time Computer Vision

[![Python](https://img.shields.io/badge/Python-3.9%2B-blue?logo=python)](https://www.python.org/)
[![YOLOv8](https://img.shields.io/badge/Detector-YOLOv8%20%7C%20Faster%20R--CNN-brightgreen)](https://ultralytics.com/)
[![Tracker](https://img.shields.io/badge/Tracker-SORT%20%7C%20DeepSORT-orange)](https://github.com/abewley/sort)
[![License](https://img.shields.io/badge/License-MIT-lightgrey)](LICENSE)

A production-ready pipeline for **real-time object detection and multi-object tracking** from webcam, video file, or RTSP stream. Mix and match detectors (YOLOv8 or Faster R-CNN) with trackers (SORT or DeepSORT) using a single YAML config.

---

## ✨ Features

- **Plug-and-play detectors** — YOLOv8 (n/s/m/l/x) and Faster R-CNN (ResNet-50, MobileNetV3)
- **Two tracking algorithms** — SORT (fast, Kalman + Hungarian) and DeepSORT (appearance re-ID)
- **Live annotated display** — colored bounding boxes, persistent track IDs, centroid trails, corner accents
- **HUD overlay** — real-time FPS, inference time, active track count
- **Zone & line analytics** — count objects entering polygonal regions or crossing virtual lines
- **Screenshot & video export** — save annotated output with one key-press or config flag
- **Fully configurable via YAML** — no code edits needed to change models, thresholds, or sources
- **CLI overrides** — swap source, model, or tracker on the fly

---

## 🗂️ Project Structure

```
object_detection_tracking/
├── run.py                      ← Main entry point
├── requirements.txt
│
├── src/
│   ├── detector.py             ← YOLODetector, FasterRCNNDetector, build_detector()
│   ├── tracker.py              ← SORTTracker, DeepSORTTracker, build_tracker()
│   └── visualizer.py           ← Bounding-box drawing, HUD, zone overlays
│
├── utils/
│   ├── video_io.py             ← VideoReader, VideoWriter, FPSCounter
│   └── analytics.py            ← ZoneCounter, LineCrossingCounter, TrackStatistics
│
├── configs/
│   ├── yolo_sort.yaml          ← YOLOv8n + SORT  (fast, CPU-friendly)
│   ├── yolo_deepsort.yaml      ← YOLOv8s + DeepSORT  (best re-ID)
│   └── fasterrcnn_sort.yaml    ← Faster R-CNN + SORT
│
├── tests/
│   └── test_core.py            ← Unit tests (pytest)
│
└── output/                     ← Auto-created; screenshots + saved videos go here
```

---

## 🚀 Quick Start

### 1. Clone & install

```bash
git clone https://github.com/YOUR_USERNAME/object_detection_tracking.git
cd object_detection_tracking

# Create a virtual environment (recommended)
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# Install core dependencies
pip install -r requirements.txt
```

> **CUDA users:** install a CUDA-enabled PyTorch first from [pytorch.org](https://pytorch.org/get-started/locally/), then run the above.

### 2. Run on your webcam

```bash
# Default: YOLOv8n + SORT, webcam 0
python run.py

# DeepSORT with appearance re-ID
python run.py --config configs/yolo_deepsort.yaml

# Faster R-CNN on a video file
python run.py --config configs/fasterrcnn_sort.yaml --source videos/street.mp4
```

### 3. Common CLI overrides

```bash
# Use a bigger YOLO model
python run.py --model yolov8m.pt

# Detect only people (COCO class 0) with higher confidence
python run.py --conf 0.60

# Save the annotated video
python run.py --save-video

# Run headless (no window) and save
python run.py --no-display --save-video --source videos/crowd.mp4

# Force CPU
python run.py --device cpu
```

---

## ⌨️ Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `q` / `Esc` | Quit |
| `p` | Pause / Resume |
| `s` | Screenshot → `output/screenshots/` |
| `t` | Toggle centroid trail |
| `h` | Toggle HUD overlay |

---

## ⚙️ Configuration Reference

All settings live in a YAML file. The three bundled configs cover the most common setups. Key fields:

```yaml
source: 0                  # 0 = webcam | "path/to/video.mp4" | "rtsp://..."

detector:
  type: yolo               # "yolo" or "faster_rcnn"
  model_path: yolov8n.pt   # YOLOv8: n/s/m/l/x.pt  |  Faster R-CNN: model name
  conf_threshold: 0.40     # detection confidence floor
  iou_threshold:  0.45     # NMS overlap threshold (YOLO only)
  classes: null            # null = all | [0] = person | [2,5,7] = car/bus/truck
  device: ""               # "" = auto | "cuda" | "cpu"

tracker:
  type: sort               # "sort" or "deepsort"
  max_age: 30              # frames before a lost track is deleted
  min_hits: 3              # frames before a new track is confirmed
  iou_threshold: 0.30      # SORT association threshold

  # DeepSORT extras:
  embedder: mobilenet      # "mobilenet" | "torchreid" | "clip_ViT-B/16"
  max_cosine_dist: 0.4
  nn_budget: 100

analytics:
  enabled: true
  zones:
    - name: "Entrance"
      polygon: [[100,200],[400,200],[400,500],[100,500]]
  line_crossings:
    - name: "Gate"
      p1: [0, 360]
      p2: [1280, 360]
```

---

## 🏗️ Architecture

```
VideoReader
    │
    ▼
┌─────────────────────────────────────────────────┐
│              Detection Engine                   │
│  YOLODetector  ──or──  FasterRCNNDetector       │
│  Returns: List[Detection(bbox, conf, class)]    │
└──────────────────────┬──────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────┐
│              Tracking Engine                    │
│  SORTTracker (Kalman + Hungarian matching)      │
│    ──or──                                       │
│  DeepSORTTracker (Kalman + appearance re-ID)    │
│  Returns: List[TrackedObject(id, bbox, class)]  │
└──────────────────────┬──────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────┐
│              Analytics (optional)               │
│  ZoneCounter · LineCrossingCounter              │
│  TrackStatistics                                │
└──────────────────────┬──────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────┐
│              Visualizer                         │
│  draw_tracked_objects() → bounding boxes        │
│  draw_hud()             → FPS / stats overlay   │
│  draw_zone()            → polygon overlays      │
└──────────────────────┬──────────────────────────┘
                       │
              cv2.imshow / VideoWriter
```

---

## 📊 Algorithm Overview

### SORT (Simple Online and Realtime Tracking)
1. **Predict** — each existing track is propagated forward using a Kalman filter
2. **Associate** — detections are matched to predictions via IoU and the Hungarian algorithm
3. **Update** — matched tracks absorb new measurement; unmatched detections spawn new tracks

### DeepSORT
Extends SORT with a deep appearance descriptor (CNN embedding). Instead of IoU alone, a combined cost matrix uses both spatial proximity and visual similarity, dramatically reducing ID switches for objects that occlude each other.

### YOLOv8
Single-stage anchor-free detector. Each frame is processed in a single forward pass producing class scores, objectness, and bounding boxes with NMS applied. Use the `n` variant for >60 FPS on CPU or the `x` variant for maximum accuracy on GPU.

### Faster R-CNN
Two-stage detector: a Region Proposal Network (RPN) first proposes candidate regions, then a classification head refines them. More accurate but ~5–10× slower than YOLOv8.

---

## 🧪 Running Tests

```bash
pip install pytest
pytest tests/ -v
```

---

## 📦 Dependencies

| Package | Purpose |
|---------|---------|
| `opencv-python` | Video I/O, drawing, display |
| `ultralytics` | YOLOv8 inference |
| `torch` + `torchvision` | Faster R-CNN inference |
| `filterpy` | Kalman filter for SORT |
| `scipy` | Hungarian algorithm for SORT |
| `deep-sort-realtime` | DeepSORT tracking |
| `PyYAML` | Config file parsing |

---

## 🤝 Contributing

1. Fork the repo and create a feature branch
2. Make your changes with clear commit messages
3. Add or update tests in `tests/`
4. Open a pull request describing your changes

---

## 📄 License

This project is licensed under the **MIT License** — see [LICENSE](LICENSE) for details.

---

## 🙏 Acknowledgements

- [Ultralytics YOLOv8](https://github.com/ultralytics/ultralytics)
- [SORT — Bewley et al., 2016](https://github.com/abewley/sort)
- [DeepSORT — Wojke et al., 2017](https://github.com/nwojke/deep_sort)
- [deep-sort-realtime](https://github.com/levan92/deep_sort_realtime)
- [torchvision detection models](https://pytorch.org/vision/stable/models.html#object-detection)
