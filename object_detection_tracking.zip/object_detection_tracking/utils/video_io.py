"""
utils/video_io.py — Video capture and writing helpers, FPS counter.
"""

from __future__ import annotations
import time
from collections import deque
from pathlib import Path
from typing import Generator, Optional, Tuple

import cv2
import numpy as np


# ─── FPS counter ──────────────────────────────────────────────────────────────

class FPSCounter:
    """Sliding-window FPS estimator."""

    def __init__(self, window: int = 30):
        self._times: deque = deque(maxlen=window)
        self._last: Optional[float] = None

    def tick(self) -> float:
        now = time.perf_counter()
        if self._last is not None:
            self._times.append(now - self._last)
        self._last = now
        if len(self._times) == 0:
            return 0.0
        return 1.0 / (sum(self._times) / len(self._times))

    @property
    def fps(self) -> float:
        if not self._times:
            return 0.0
        return 1.0 / (sum(self._times) / len(self._times))


# ─── Video reader ─────────────────────────────────────────────────────────────

class VideoReader:
    """
    Thin wrapper around cv2.VideoCapture with iterator support.

    Parameters
    ----------
    source      : 0 for webcam, or path to a video file / RTSP URL.
    width, height : optional resize resolution (0 = keep native).
    """

    def __init__(
        self,
        source: int | str = 0,
        width: int = 0,
        height: int = 0,
    ):
        self.source = source
        self._target_w = width
        self._target_h = height
        self.cap = cv2.VideoCapture(source)
        if not self.cap.isOpened():
            raise IOError(f"Cannot open video source: {source!r}")

    @property
    def native_width(self) -> int:
        return int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))

    @property
    def native_height(self) -> int:
        return int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    @property
    def fps(self) -> float:
        return self.cap.get(cv2.CAP_PROP_FPS) or 30.0

    @property
    def frame_count(self) -> int:
        return int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))

    def read(self) -> Optional[np.ndarray]:
        ret, frame = self.cap.read()
        if not ret:
            return None
        if self._target_w and self._target_h:
            frame = cv2.resize(frame, (self._target_w, self._target_h))
        return frame

    def __iter__(self) -> Generator[np.ndarray, None, None]:
        while True:
            frame = self.read()
            if frame is None:
                break
            yield frame

    def release(self) -> None:
        self.cap.release()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.release()


# ─── Video writer ─────────────────────────────────────────────────────────────

class VideoWriter:
    """
    Wrapper around cv2.VideoWriter.

    Parameters
    ----------
    path    : output file path.
    fps     : frames per second.
    size    : (width, height) tuple.
    fourcc  : codec FourCC string (default 'mp4v').
    """

    def __init__(
        self,
        path: str | Path,
        fps: float,
        size: Tuple[int, int],
        fourcc: str = "mp4v",
    ):
        self.path = str(path)
        code = cv2.VideoWriter_fourcc(*fourcc)
        self._writer = cv2.VideoWriter(self.path, code, fps, size)
        if not self._writer.isOpened():
            raise IOError(f"Cannot open VideoWriter at: {self.path!r}")

    def write(self, frame: np.ndarray) -> None:
        self._writer.write(frame)

    def release(self) -> None:
        self._writer.release()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.release()


# ─── Convenience: resize keeping aspect ratio ─────────────────────────────────

def letterbox(
    img: np.ndarray,
    target: Tuple[int, int],
    color: Tuple[int, int, int] = (114, 114, 114),
) -> np.ndarray:
    """Resize + pad to target (W, H) without distortion."""
    th, tw = target[1], target[0]
    ih, iw = img.shape[:2]
    scale = min(tw / iw, th / ih)
    nw, nh = int(iw * scale), int(ih * scale)
    resized = cv2.resize(img, (nw, nh))
    canvas = np.full((th, tw, 3), color, dtype=np.uint8)
    dx, dy = (tw - nw) // 2, (th - nh) // 2
    canvas[dy: dy + nh, dx: dx + nw] = resized
    return canvas
