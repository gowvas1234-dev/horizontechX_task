"""
utils/analytics.py — Object counting, zone analytics, and basic statistics.
"""

from __future__ import annotations
from collections import defaultdict
from typing import Dict, List, Optional, Set, Tuple

import numpy as np

from ..src.tracker import TrackedObject


# ─── Point-in-polygon ─────────────────────────────────────────────────────────

def point_in_polygon(point: Tuple[int, int], polygon: List[Tuple[int, int]]) -> bool:
    """Ray-casting algorithm for point-in-polygon test."""
    x, y = point
    inside = False
    n = len(polygon)
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i]
        xj, yj = polygon[j]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi + 1e-9) + xi):
            inside = not inside
        j = i
    return inside


# ─── Zone Counter ─────────────────────────────────────────────────────────────

class ZoneCounter:
    """
    Count unique objects that enter a polygonal zone.

    Parameters
    ----------
    zone_polygon : list of (x, y) vertices defining the zone.
    name         : human-readable zone label.
    """

    def __init__(self, zone_polygon: List[Tuple[int, int]], name: str = "Zone"):
        self.polygon = zone_polygon
        self.name = name
        self._inside_now: Set[int] = set()
        self._total_in: int = 0
        self._total_out: int = 0

    def update(self, tracks: List[TrackedObject]) -> Dict:
        """Update zone state and return event summary."""
        current_ids = {t.track_id for t in tracks if point_in_polygon(t.center, self.polygon)}
        entered = current_ids - self._inside_now
        exited  = self._inside_now - current_ids

        self._total_in  += len(entered)
        self._total_out += len(exited)
        self._inside_now = current_ids

        return {
            "zone": self.name,
            "inside_count": len(self._inside_now),
            "entered": entered,
            "exited": exited,
            "total_entries": self._total_in,
            "total_exits": self._total_out,
        }

    @property
    def current_count(self) -> int:
        return len(self._inside_now)


# ─── Line Crossing Counter ────────────────────────────────────────────────────

class LineCrossingCounter:
    """
    Count objects crossing a virtual line (direction-aware).

    Parameters
    ----------
    p1, p2     : endpoints of the crossing line.
    name       : label for this counter.
    """

    def __init__(
        self,
        p1: Tuple[int, int],
        p2: Tuple[int, int],
        name: str = "Line",
    ):
        self.p1 = np.array(p1, dtype=float)
        self.p2 = np.array(p2, dtype=float)
        self.name = name
        self._prev_side: Dict[int, float] = {}
        self.count_a_to_b = 0
        self.count_b_to_a = 0

    def _side(self, point: Tuple[int, int]) -> float:
        """Return signed cross-product (which side of the line the point is on)."""
        p = np.array(point, dtype=float)
        d = self.p2 - self.p1
        return float(np.cross(d, p - self.p1))

    def update(self, tracks: List[TrackedObject]) -> Dict:
        events = []
        for t in tracks:
            side_now = self._side(t.center)
            if t.track_id in self._prev_side:
                side_prev = self._prev_side[t.track_id]
                if side_prev < 0 and side_now >= 0:
                    self.count_a_to_b += 1
                    events.append({"id": t.track_id, "direction": "A→B"})
                elif side_prev >= 0 and side_now < 0:
                    self.count_b_to_a += 1
                    events.append({"id": t.track_id, "direction": "B→A"})
            self._prev_side[t.track_id] = side_now
        # Prune ids no longer present
        active_ids = {t.track_id for t in tracks}
        self._prev_side = {k: v for k, v in self._prev_side.items() if k in active_ids}
        return {
            "line": self.name,
            "A_to_B": self.count_a_to_b,
            "B_to_A": self.count_b_to_a,
            "events": events,
        }


# ─── Track statistics ─────────────────────────────────────────────────────────

class TrackStatistics:
    """
    Lightweight statistics collector for all observed tracks.
    Stores per-class counts and per-track lifetime.
    """

    def __init__(self):
        self._class_counts: Dict[str, Set[int]] = defaultdict(set)   # class → set of unique track ids
        self._track_lifetimes: Dict[int, int] = {}                    # track_id → max hits seen

    def update(self, tracks: List[TrackedObject]) -> None:
        for t in tracks:
            self._class_counts[t.class_name].add(t.track_id)
            self._track_lifetimes[t.track_id] = max(
                self._track_lifetimes.get(t.track_id, 0), t.hits
            )

    def summary(self) -> Dict:
        return {
            "total_unique_objects": len(self._track_lifetimes),
            "by_class": {k: len(v) for k, v in self._class_counts.items()},
            "avg_track_lifetime": (
                sum(self._track_lifetimes.values()) / len(self._track_lifetimes)
                if self._track_lifetimes else 0.0
            ),
        }
